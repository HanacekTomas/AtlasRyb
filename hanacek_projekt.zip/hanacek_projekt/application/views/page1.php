<style>
     :root {
          --gradient: linear-gradient(to left top, #83eaf1 10%, #63a4ff 90%) !important;
     }

     body {
          background: #111 !important;
     }

     .card {
          background: #222;
          border: 1px solid #0652c5;
          color: rgba(250, 250, 250, 0.8);
          margin-bottom: 2rem;
     }

     .btn {
          border: 3px solid;
          border-image-slice: 1;
          background: var(--gradient) !important;
          -webkit-background-clip: text !important;
          -webkit-text-fill-color: transparent !important;
          border-image-source: var(--gradient) !important;
          text-decoration: none;
          transition: all .4s ease;
     }

     .btn:hover,
     .btn:focus {
          
          border: 5px solid #fff !important;
          box-shadow: #222 1px 0 10px;
     }
     h1 {
  font-size: 72px;
  background: linear-gradient(#b621fe, #1fd1f9);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>
     <h1>ATLAS</h1>
     <div class="container mx-auto ">
          <div class="row">
               <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 26rem;">
                         <img class="image" src="http://www.chytej.cz/foto/clanky/2010/858/08.jpg" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b>Maloostní</b></h5>
                              <p class="card-text">- řád ryb z podtřídy paprskoploutvých; zahrnuje převážně sladkovodní druhy obývající všechny kontinenty kromě Antarktidy a Grónska.</p>
                              <a href="maloostni" class="btn mr-2"><i class="fas fa-info-circle"></i> Více</a>
                              <a href="https://cs.wikipedia.org/wiki/Máloostní" class="btn "><i class="fas fa-link"></i></i> Odkaz</a>
                         </div>
                    </div> 
               </div>

               <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 26rem;">
                         <img class="image" src="https://www.chytej.cz/foto/atlas_ryb/candat_obecny/zakladni_informace/Candat-detail.jpg" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b>Ostnoploutví</b></h5>
                              <p class="card-text">- nejpočetnější řád ryb z podtřídy paprskoploutvých. Zahrnuje mořské, brakické i sladkovodní druhy, řazené do 147 čeledí.</p>
                              <a href="ostnoploutvi" class="btn  mr-2"><i class="fas fa-info-circle"></i> Více</a>
                              <a href="https://cs.wikipedia.org/wiki/Ostnoploutví" class="btn"><i class="fas fa-link"></i> Odkaz</a>
                         </div>
                    </div>
               </div>

               <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 26rem;">
                         <img class="image" src="https://www.chytej.cz/foto/atlas_ryb/lipan_podhorni/rozlisovaci_znaky/Lipan-Sander.jpg" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b>Bezostní</b></h5>
                              <p class="card-text">- řád ryb z podtřídy paprskoploutvých; dělí se do čtyř čeledí se 72 rody a zahrnuje 292 druhů.</p>
                              <br/>
                              <a href="bezostni" class="btn mr-2"><i class="fas fa-info-circle"></i> Více</a>
                              <a href="https://cs.wikipedia.org/wiki/Bezostní" class="btn "><i class="fas fa-link"></i> Odkaz</a>
                         </div>
                    </div>
               </div>

               <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 26rem;">
                         <img class="image" src="https://www.rybarskyrozcestnik.cz/wp-content/uploads/2015/12/Acipenser_gueldenstaedti2.jpg" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b>Jeseteři</b></h5>
                              <p class="card-text">- řád ryb z podtřídy paprskoploutvých; dělí se na čtyři rody s 23 druhy sladkovodních či anadromních ryb (to je třou se ve sladkých vodách)</p>
                              <a href="jeseteri" class="btn mr-2"><i class="fas fa-info-circle"></i> Více</a>
                              <a href="https://cs.wikipedia.org/wiki/Jeseteři" class="btn"><i class="fas fa-link"></i> Odkaz</a>
                         </div>
                    </div>
               </div>

               <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 26rem;">
                         <img class="image" src="https://www.crsmsodry.cz/wp-content/uploads/2018/07/gasterosteus_aculeatus_koljuska-triostna_04.jpg" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b>Volnoostní</b></h5>
                              <p class="card-text">– řád ryb z podtřídy paprskoploutvých. Zahrnuje devět rodů s 10 druhy; většinou malé ryby, obývající mořské, brakické i sladkovodní vody.</p>
                              <a href="volnoostni" class="btn mr-2"><i class="fas fa-info-circle"></i> Více</a>
                              <a href="https://leporelo.info/volnoostni" class="btn"><i class="fas fa-link"></i >Odkaz</a>
                         </div>
                    </div>
               </div>

               <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 26rem;">
                         <img class="image" src="http://www.chovzvirat.cz/images/zvirata/uhor-ricni_agl69ie.jpg" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b>Holobřiší</b></h5>
                              <p class="card-text">– řád ryb z podtřídy paprskoploutvých. Dělí se do 133 rodů, které zahrnují na 603 druhy; mořské i sladkovodní.</p>
                              <br/>
                              <a href="holobrisi" class="btn mr-2"><i class="fas fa-info-circle"></i> Více</a>
                              <a href="https://cs.wikipedia.org/wiki/Holobřiší" class="btn"><i class="fas fa-link"></i> Odkaz</a>
                         </div>
                    </div>
               </div>

               <div class="col-md-4">
                    <div class="card" style="width: 18rem; height: 26rem;">
                         <img class="image" src="https://www.chytej.cz/foto/atlas_ryb/mnik_jednovousy/zakladni_informace/Mnik.jpg" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b>Hrdloploutví</b></h5>
                              <p class="card-text">– řád ryb z podtřídy paprskoploutvých. Dělí se do 10 čeledí a 168 rodů. Většinou mořské ryby, pouze několik druhů je sladkovodních.</p>
                              <a href="hrdloploutvi" class="btn mr-2"><i class="fas fa-info-circle"></i> Více</a>
                              <a href="https://leporelo.info/hrdloploutvi" class="btn"><i class="fas fa-link"></i> Odkaz</a>
                         </div>
                    </div>
               </div>


          </div>
     </div>
