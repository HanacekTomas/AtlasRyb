
<h1>Přihlášení</h1>




<?php echo form_open("auth/login");?>

  <p>
    <?php echo lang('login_identity_label', 'identity');?>
    <?php echo form_input($identity);?>
  </p>

  <p>
    <?php echo lang('login_password_label', 'password');?>
    <?php echo form_input($password);?>
  </p>

 


  <p><?php echo form_submit('submit', lang('login_submit_btn'));?></p>

<?php echo form_close();?>

<a href="hanacek_projekt/uvod"><button type="button" style="border-radius: 2px;" class="btn btn-primary btn-md"><i class="fas fa-chevron-left fa-sm"></i> zpět</button></a>
