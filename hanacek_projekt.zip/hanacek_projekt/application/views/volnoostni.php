<style>
     :root {
          --gradient: linear-gradient(to left top, #83eaf1 10%, #63a4ff 90%) !important;
     }

     body {
          background: #111 !important;
     }

     .card {
          background: #222;
          border: 1px solid #0652c5;
          color: rgba(250, 250, 250, 0.8);
          margin-bottom: 2rem;
     }
     .image {
  transition: transform .2s; /* Animation */
}

.image:hover {
  transform: scale(1.5); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
h1 {
  font-size: 72px;
  background: linear-gradient(#b621fe, #1fd1f9);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>
<h1>Volnoostní</h1>
<div class="col">
<a href="atlas"><button type="button" style="border-radius: 2px;" class="btn btn-primary btn-md"><i class="fas fa-chevron-left fa-sm"></i> zpět</button></a>
<div class="row">
     <?php foreach ($data as $key => $row) : ?>
          <div class="row" style="margin: 10px">
               <div class="col">
                    <div class="card" style="width: 18rem; height: 23rem">
                         <img class="image" src="<?= $row->obrazek_volnoostni ?>" style="height: 200px">
                         <div class="card-body">
                              <h5 class="card-title"><b><?= $row->nazev_volnoostni ?></b></h5>
                              <p class="card-text" style="text-align: left"><?= $row->popis_volnoostni ?></p>
                         </div>
                    </div>
               </div>
          </div>
     <?php endforeach; ?>
</div>
     </div>