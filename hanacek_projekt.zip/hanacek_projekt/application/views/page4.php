<style>
     :root {
          --gradient: linear-gradient(to left top, #83eaf1 10%, #63a4ff 90%) !important;
     }

     body {
          background: #444 !important;
     }
     h1 {
  font-size: 72px;
  background: linear-gradient(#b621fe, #1fd1f9);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
h5 {
  color: #fff;

}
.btn {
          border: 3px solid;
          border-image-slice: 1;
          background: var(--gradient) !important;
          -webkit-background-clip: text !important;
          -webkit-text-fill-color: transparent !important;
          border-image-source: var(--gradient) !important;
          text-decoration: none;
          transition: all .4s ease;
     }
     .btn:hover,
     .btn:focus {
          
          border: 5px solid #fff !important;
          box-shadow: #222 1px 0 10px;
     }
</style>

<div style="padding-top: 3rem;">
<h1>Přidej úlovek</h1>

<?php
$this->load->helper('form');

echo form_open('pridej/odesli');
?>
<div class="form-group">
<?php
echo form_label('<h5>Název</h5>', 'nazev_ulovku');
echo form_input('nazev_ulovku', '', 'class="form-control"');

echo form_label('<h5>Délka</h5>', 'delka_ulovku');
echo form_input('delka_ulovku', '', 'class="form-control"');

echo form_label('<h5>Obrázek (link)</h5>', 'obrazek_ulovku');
echo form_input('obrazek_ulovku', '', 'class="form-control"');
?>
</div>
   <input class="btn" type="Submit" name="Submit">
</form>

<a href="ulovky" class="btn btn-primary float-right">Zpět</a>
</div>
<!--<input type="file" accept="image/png, image/jpeg">-->