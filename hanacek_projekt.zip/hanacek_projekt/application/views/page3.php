<style>
     :root {
          --gradient: linear-gradient(to left top, #83eaf1 10%, #63a4ff 90%) !important;
     }

     body {
          background: #111 !important;
     }
     h1 {
  font-size: 72px;
  background: linear-gradient(#b621fe, #1fd1f9);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.card {
          background: #222;
          border: 1px solid #0652c5;
          color: rgba(250, 250, 250, 0.8);
          margin-bottom: 2rem;
     }
.btn {
          border: 3px solid;
          border-image-slice: 1;
          background: var(--gradient) !important;
          -webkit-background-clip: text !important;
          -webkit-text-fill-color: transparent !important;
          border-image-source: var(--gradient) !important;
          text-decoration: none;
          transition: all .4s ease;
     }
     .btn:hover,
     .btn:focus {
          
          border: 5px solid #fff !important;
          box-shadow: #222 1px 0 10px;
     }
</style>
<?php echo anchor('pridej-ulovek', 'přidat', 'class = "btn btn-success btn-block"'); ?>

<h1>VAŠE ÚLOVKY</h1>
<div class="col">
<div class="row">
          <?php foreach ($data as $key => $row) : ?>
               <div class="row" style="margin: 10px">
                    <div class="col">
                         <div class="card" style="width: 18rem; height: 18rem">
                              <img class="image" src="<?= $row->obrazek_ulovku ?>" style="height: 200px">
                              <div class="card-body">
                                   <h5 class="card-title"><b><?= $row->nazev_ulovku ?></b></h5>
                                   <p class="card-text" style="text-align: left"><?= $row->delka_ulovku ?> CM</p>
                              </div>
                         </div>
                    </div>
               </div>
          <?php endforeach; ?>
     </div>
          </div>