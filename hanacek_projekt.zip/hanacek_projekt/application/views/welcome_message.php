<style>
     :root {
          --gradient: linear-gradient(to left top, #83eaf1 10%, #63a4ff 90%) !important;
     }

     body {
          background: #111 !important;
     }

     .div {
          background: #222;
          border: 1px solid #0652c5;
          color: rgba(250, 250, 250, 0.8);
          margin-bottom: 2rem;
     }
</style>



<div class="jumbotron center">
     <center>
          <h1>Stránka vznikla jako projekt na OAUH</h1>
     </center>
     <center>
          <img src="http://www.oauh.cz/images/fb-image.png" style="margin-top: 10px">
     </center>
</div>