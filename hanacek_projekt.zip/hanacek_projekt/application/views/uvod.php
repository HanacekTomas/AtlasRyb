<style>
     :root {
          --gradient: linear-gradient(to left top, #83eaf1 10%, #63a4ff 90%) !important;
     }

     body {
          background: #111 !important;
     }

     .div {
          background: #222;
          border: 1px solid #0652c5;
          color: rgba(250, 250, 250, 0.8);
          margin-bottom: 2rem;
     }
     h1 {
  font-size: 72px;
  background: linear-gradient(#b621fe, #1fd1f9);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>




<div class="jumbotron center" style="background-color: #222;">

     <center>
         <h1><b>ATLAS RYB</b></h1>
          <h3 style="color: #FFF;">Stránka vznikla jako projekt na OAUH</h3>
          <img src="http://www.oauh.cz/images/fb-image.png" style="margin-top: 10px">
     </center>
</div>

