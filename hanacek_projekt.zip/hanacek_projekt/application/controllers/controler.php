<?php

class controler extends CI_Controller 
{

    function __construct() 
    {
        parent::__construct();
        $this->load->model('model');
    }

    public function maloostni()
    {
        $data['data'] = $this->model->getMaloostni();
        $data['main'] = 'maloostni';
        $data['title'] = 'Maloostní';
        $this->layout->generate($data);
    }

    public function jeseteri()
    {
        $data['data'] = $this->model->getJeseteri();
        $data['main'] = 'jeseteri';
        $data['title'] = 'Jeseteři';
        $this->layout->generate($data);
    }

    public function volnoostni()
    {
        $data['data'] = $this->model->getVolnoostni();
        $data['main'] = 'volnoostni';
        $data['title'] = 'Volnoostní';
        $this->layout->generate($data);
    }

    public function holobrisi()
    {
        $data['data'] = $this->model->getHolobrisi();
        $data['main'] = 'holobrisi';
        $data['title'] = 'Holobřiší';
        $this->layout->generate($data);
    }

    public function bezostni()
    {
        $data['data'] = $this->model->getBezostni();
        $data['main'] = 'bezostni';
        $data['title'] = 'Bezostní';
        $this->layout->generate($data);
    }

    public function ostnoploutvi()
    {
        $data['data'] = $this->model->getOstnoploutvi();
        $data['main'] = 'ostnoploutvi';
        $data['title'] = 'Ostnoploutví';
        $this->layout->generate($data);
    }

    public function hrdloploutvi()
    {
        $data['data'] = $this->model->getHrdloploutvi();
        $data['main'] = 'hrdloploutvi';
        $data['title'] = 'Hrdloploutví';
        $this->layout->generate($data);
    }

    public function page4()
    {
        $data['title'] = 'Přidej úlovek';
        $data['main'] = 'page4';
        $this->layout->generate($data);
    }

    public function pridejsend()
    {
        $this->model->pridej($this->input->post('nazev_ulovku'), $this->input->post('delka_ulovku'), $this->input->post('obrazek_ulovku'));
        redirect('ulovky');
    }
    
    public function page3()
    {
        $data['data'] = $this->model->getUlovek();
        $data['main'] = 'page3';
        $data['title'] = 'Úlovky';
        $this->layout->generate($data);
    }
    
    




}

