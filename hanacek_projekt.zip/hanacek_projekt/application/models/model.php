<?php
class model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

   



    public function getMaloostni()
    {
        $this->db->select('');
        $this->db->from('maloostni');
        $result = $this->db->get()->result();
        return $result;
    }

    public function getJeseteri()
    {
        $this->db->select('');
        $this->db->from('jeseteri');
        $result = $this->db->get()->result();
        return $result;
    }

    public function getVolnoostni()
    {
        $this->db->select('');
        $this->db->from('volnoostni');
        $result = $this->db->get()->result();
        return $result;
    }

    public function getHolobrisi()
    {
        $this->db->select('');
        $this->db->from('holobrisi');
        $result = $this->db->get()->result();
        return $result;
    }

    public function getBezostni()
    {
        $this->db->select('');
        $this->db->from('bezostni');
        $result = $this->db->get()->result();
        return $result;
    }

    public function getOstnoploutvi()
    {
        $this->db->select('');
        $this->db->from('ostnoploutvi');
        $result = $this->db->get()->result();
        return $result;
    }

    public function getHrdloploutvi()
    {
        $this->db->select('');
        $this->db->from('hrdloploutvi');
        $result = $this->db->get()->result();
        return $result;
    }

    public function pridej($jmeno, $delka, $obrazek)
    {
        $data = array('nazev_ulovku' => $jmeno, 'delka_ulovku' => $delka, 'obrazek_ulovku' => $obrazek);
        $this->db->insert('vlastni_ulovky', $data);
    }
    
    public function getUlovek()
    {
        $this->db->select('');
        $this->db->from('vlastni_ulovky');
        $result = $this->db->get()->result();
        return $result;
    }
    
}    